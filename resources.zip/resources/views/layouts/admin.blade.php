<!DOCTYPE html>
<html lang="vi">
<head>

<meta charset="UTF-8">
<title>Admin - BabyCute Apartment</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{
background:#f4f6f9;
}

.sidebar{
height:100vh;
width:240px;
position:fixed;
background:#1f2d3d;
color:white;
}

.sidebar a{
display:block;
padding:12px;
color:#c2c7d0;
text-decoration:none;
}

.sidebar a:hover{
background:#34495e;
color:white;
}

.content{
margin-left:240px;
padding:25px;
}

.brand{
font-size:20px;
font-weight:bold;
padding:15px;
}

.sidebar a.active{
background:#1abc9c;
color:white;
font-weight:bold;
}

</style>

</head>

<body>

<div class="sidebar">

<h3>BabyCute Admin</h3>

<a href="/admin"
class="{{ request()->is('admin') ? 'active' : '' }}">
Dashboard
</a>

<h4>Quản lý căn hộ</h4>

<a href="/can-ho"
class="{{ request()->is('can-ho*') ? 'active' : '' }}">
Danh sách căn hộ
</a>

<a href="/loai-can-ho"
class="{{ request()->is('loai-can-ho*') ? 'active' : '' }}">
Loại căn hộ
</a>

<a href="/cu-dan"
class="{{ request()->is('cu-dan*') ? 'active' : '' }}">
Cư dân
</a>

<a href="/hop-dong"
class="{{ request()->is('hop-dong*') ? 'active' : '' }}">
Hợp đồng
</a>

<h4>Tài chính</h4>

<a href="/hoa-don"
class="{{ request()->is('hoa-don*') ? 'active' : '' }}">
Hóa đơn
</a>

<a href="/thanh-toan"
class="{{ request()->is('thanh-toan*') ? 'active' : '' }}">
Thanh toán
</a>

<h4>Dịch vụ</h4>

<a href="/phan-anh"
class="{{ request()->is('phan-anh*') ? 'active' : '' }}">
Phản ánh cư dân
</a>

<a href="/thong-bao"
class="{{ request()->is('thong-bao*') ? 'active' : '' }}">
Thông báo
</a>

<hr>

<a href="/logout" class="text-danger">
<i class="fa fa-right-from-bracket"></i>
Đăng xuất
</a>

</div>

<div class="content">

@yield('content')

</div>

</body>
</html>