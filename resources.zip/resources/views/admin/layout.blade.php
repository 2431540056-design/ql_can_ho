<!DOCTYPE html>
<html lang="vi">
<head>

<meta charset="UTF-8">
<title>Admin - Căn hộ BabyCute</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{
background:#f4f6f9;
}

.sidebar{
height:100vh;
width:250px;
position:fixed;
background:#1f2d3d;
color:white;
}

.sidebar a{
display:block;
color:#c2c7d0;
padding:12px;
text-decoration:none;
}

.sidebar a:hover{
background:#34495e;
color:white;
}

.content{
margin-left:250px;
padding:25px;
}

.sidebar-title{
padding:15px;
font-size:18px;
font-weight:bold;
}

</style>

</head>

<body>

<div class="sidebar">

<div class="sidebar-title">
<i class="fa fa-building"></i>
BabyCute Admin
</div>

<hr>

<a href="/admin">
<i class="fa fa-chart-line"></i>
Dashboard
</a>

<h6 class="mt-3 ms-3">Quản lý căn hộ</h6>

<a href="/can-ho">
<i class="fa fa-house"></i>
Danh sách căn hộ
</a>

<a href="/loai-can-ho">
<i class="fa fa-layer-group"></i>
Loại căn hộ
</a>

<a href="/cu-dan">
<i class="fa fa-users"></i>
Cư dân
</a>

<a href="/hop-dong">
<i class="fa fa-file-contract"></i>
Hợp đồng
</a>

<hr>

<h6 class="ms-3">Tài chính</h6>

<a href="/hoa-don">
<i class="fa fa-file-invoice-dollar"></i>
Hóa đơn
</a>

<a href="/thanh-toan">
<i class="fa fa-money-bill"></i>
Thanh toán
</a>

<hr>

<h6 class="ms-3">Dịch vụ</h6>

<a href="/phan-anh">
<i class="fa fa-triangle-exclamation"></i>
Phản ánh cư dân
</a>

<a href="/thong-bao">
<i class="fa fa-bell"></i>
Thông báo
</a>

<hr>

<a href="/bao-cao">
<i class="fa fa-chart-pie"></i>
Báo cáo
</a>

<a href="/logout" class="text-danger">
<i class="fa fa-right-from-bracket"></i>
Đăng xuất
</a>

</div>

<div class="content">

@yield('content')

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>